package com.example.demo.controller;

import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.EmployeeServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MyController {
    //http://localhost:8080/test
    @RequestMapping("/test")
    String display(){
        return "hello world";
    }

    @Autowired
    private EmployeeService employeeService;
    //private EmployeeServiceInterface employeeServiceInterface;

    //CREATE
    @PostMapping("/create")
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee){
        Employee saved;
        try{
            saved = employeeService.addEmployee(employee);
        } catch(Exception e){
            return new ResponseEntity("Failed", HttpStatus.INTERNAL_SERVER_ERROR);
        } return new ResponseEntity("SAVED: "+saved.getId(),HttpStatus.CREATED);
    }

    //RETRIEVE ALL
    @GetMapping("/display")
    public ResponseEntity<List<Employee>> showEmployee(){
        List<Employee> list = employeeService.showEmployees();
        return new ResponseEntity<List<Employee>>(list,HttpStatus.OK);
    }

    //RETRIEVE ID
    @GetMapping("/display/{empid}")
    public ResponseEntity<Employee> showEmployee(@PathVariable("empid") int empID){
        Employee retrieved;
        try{
            retrieved = employeeService.getEmpByID(empID);
        }catch(Exception e){
            return new ResponseEntity("Failed",HttpStatus.INTERNAL_SERVER_ERROR);
        }return new ResponseEntity<Employee>(retrieved,HttpStatus.OK);
    }

    //DELETE
    @DeleteMapping("/delete/{empid}")
    public ResponseEntity<Employee> deleteEmployee(@PathVariable("empid") int empID){
        employeeService.deleteEmployee(empID);
        return new ResponseEntity("Deleted!",HttpStatus.ACCEPTED);
    }

    //UPDATE
    @PutMapping("/update")
    public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee){
        try{
            employeeService.addEmployee(employee);
        } catch(Exception e){
            return new ResponseEntity("Failed", HttpStatus.INTERNAL_SERVER_ERROR);
        } return new ResponseEntity("UPDATED: "+employee.getId(),HttpStatus.CREATED);
    }
}
