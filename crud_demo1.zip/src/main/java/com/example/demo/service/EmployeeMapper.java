package com.example.demo.service;

import com.example.demo.entity.Employee;
import com.example.demo.entity.EmployeeDTO;

public class EmployeeMapper {
    public static EmployeeDTO mapToUser(Employee employee) {
        EmployeeDTO employeeDTO = new EmployeeDTO(
                employee.getId(),
                employee.getName(),
                employee.getSalary()
        );
        return employeeDTO;
    }
    public static EmployeeDTO mapToUser(Employee employee) {
        EmployeeDTO employeeDTO = new EmployeeDTO(
                employee.getId(),
                employee.getName(),
                employee.getSalary()
        );
        return employeeDTO;
    }
}
