package com.example.demo.service;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeCrudRepository crudRepository;


    public Employee addEmployee(Employee employee) {
        Employee save = crudRepository.save(employee);
        return save;
    }

    public List<Employee> showEmployees() {
        return crudRepository.findAll();
    }

    public Employee getEmpByID(int empID) {
        return crudRepository.findById(empID).get();
    }

    public void deleteEmployee(int empID) {
        crudRepository.deleteById(empID);
    }
}
